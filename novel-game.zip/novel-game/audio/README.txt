このフォルダに以下のmp3ファイルを置いてください。
ファイルがない場合は無音でスキップされます。

【BGM】
bgm_calm.mp3      … 穏やかな日常BGM（序盤）
bgm_tension.mp3   … 不安・緊張BGM（管理人との会話）
bgm_horror.mp3    … 恐怖BGM（シルエット・クローゼット）
bgm_ending.mp3    … エンディングBGM

【効果音】
se_click.mp3      … テキスト送りクリック音
se_decision.mp3   … 選択肢決定音
se_knock.mp3      … ノック音（壁・ドア）
se_door.mp3       … ドア開閉音
se_stinger.mp3    … ホラースティンガー（ドン！系）
se_chime.mp3      … 場面転換チャイム

【おすすめ素材サイト】
魔王魂    https://maoudamashii.jokersounds.com/
効果音ラボ https://soundeffect-lab.info/
